import * as path from 'node:path';
import { fileURLToPath } from 'node:url';

// Works from src/ and compiled dist/, independent of the invocation directory.
export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
export const repoPath = (...parts: string[]) => path.resolve(ROOT, ...parts);
export const RESULTS_DIR = repoPath(process.env.POR_RESULTS_DIR ?? 'data/results/zk-validation');
if (RESULTS_DIR === repoPath('data/results') || RESULTS_DIR.startsWith(repoPath('data/results/archive') + path.sep)) {
  throw new Error('Choose a separate results directory; original non-ZK measurements are preserved.');
}
export const resultPath = (name: string) => path.join(RESULTS_DIR, name);
export const PROVER_NAME = 'RunProver';
export const VK_PATH = path.join('target', 'vk-zk', 'vk');
