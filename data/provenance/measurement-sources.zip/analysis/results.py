"""Shared result-directory selection. Never overwrite the original non-ZK experiment."""
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RESULTS = (ROOT / os.environ.get('POR_RESULTS_DIR', 'data/results/zk-bench')).resolve()
if RESULTS == (ROOT / 'data/results').resolve():
    raise ValueError('Original non-ZK results are read-only; select a separate POR_RESULTS_DIR')
